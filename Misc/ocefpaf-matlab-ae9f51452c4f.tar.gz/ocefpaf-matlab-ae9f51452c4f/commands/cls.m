% 
% cls.m
% purpose:  clear all
% author:   Filipe P. A. Fernandes
% e-mail:   ocefpaf@gmail.com
% web:      http://ocefpaf.tiddlyspot.com/
% date:     15-Oct-2004
% modified: Wed 08 Dec 2010 04:04:58 PM EST
%
% obs: 
%

hold off; close all; clear all; clear global; clc; clear function; fclose all;

% nctoolbox
%global nctbx_options
%nctbx_options.theAutoNaN=1;
%nctbx_options.theAutoscale=1;

% easy trig
%global DEG2RAD
%global RAD2DEG
%DEG2RAD = pi/180;
%RAD2DEG = 180/pi;

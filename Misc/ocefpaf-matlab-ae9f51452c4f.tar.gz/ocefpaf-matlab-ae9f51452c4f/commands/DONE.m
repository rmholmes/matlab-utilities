% 
% DONE.m
% author:   Filipe P. A. Fernandes
% e-mail:   ocefpaf@gmail.com
% web:      http://ocefpaf.tiddlyspot.com/
% date:     02-Jan-2010
% modified: 02-Jan-2010
%
% obs: show a done box for long scripts
%

questdlg('DONE','','Continue','Continue');

function x = asinh(x)
% asinh for AD objects.
x=1/sinh(x);

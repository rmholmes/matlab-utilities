function x = asech(x)
% assech for AD objects.
x=1/sech(x);
function x = tan(x)
% Tan for AD objects.


 x = sin(x)/cos(x);

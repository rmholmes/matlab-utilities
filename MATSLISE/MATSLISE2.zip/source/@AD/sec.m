function x = sec(x)
% SEC for sec objects.

x=1/cos(x);
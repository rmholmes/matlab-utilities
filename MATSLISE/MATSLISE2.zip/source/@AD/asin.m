function x = asin(x)
% asin for AD objects.
x=1/sin(x);






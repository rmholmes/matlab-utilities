function x = acot(x)
% acotan for AD objects.
x=1/cot(x);
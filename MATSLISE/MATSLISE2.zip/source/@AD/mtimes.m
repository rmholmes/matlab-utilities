function y = mtimes(x,y)
% Multiply AD objects.
y=times(x,y);
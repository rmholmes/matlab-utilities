function x = asec(x)
% asec for AD objects.
x=1/sec(x);
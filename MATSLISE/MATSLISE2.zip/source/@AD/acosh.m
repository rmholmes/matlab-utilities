function x = acosh(x)
% acosh for AD objects.
x = 1/cosh(x);
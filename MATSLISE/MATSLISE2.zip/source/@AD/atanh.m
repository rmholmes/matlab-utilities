function x = atanh(x)
% atanh for AD objects.
x=1/tanh(x);
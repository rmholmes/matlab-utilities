function x = acsch(x)
% acsch for AD objects.
x=1/csch(x);
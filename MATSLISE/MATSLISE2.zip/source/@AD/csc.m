function x = csc(x)
% csc for AD objects.

x=1/sin(x);
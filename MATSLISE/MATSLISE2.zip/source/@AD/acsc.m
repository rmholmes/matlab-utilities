function x = acsc(x)
% acsc for AD objects.
x=1/csc(x);
function x = sqrt(x)

% sqrt for AD objects.

x=x^(1/2);

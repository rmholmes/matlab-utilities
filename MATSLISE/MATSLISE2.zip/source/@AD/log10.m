function x= log10(x)
% LOG10(X) for  AD object

x=log(x)/log(10);








function x = atan(x)
% atan for AD objects.
x=1/tan(x);
function x = acos(x)
% ACOS for AD objects.
x=1/cos(x);
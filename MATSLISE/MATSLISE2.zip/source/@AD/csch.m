function x = csch(x)
% csch for AD objects.

x=1/sinh(x);
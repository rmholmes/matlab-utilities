function x = sech(x)
% Sech for AD objects.

x=1/cosh(x);

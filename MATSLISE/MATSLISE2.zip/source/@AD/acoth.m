function x = acoth(x)
% acotanh for AD objects.
x=1/coth(x);
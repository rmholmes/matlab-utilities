addpath(genpath('source'))
addpath(genpath('examples'))